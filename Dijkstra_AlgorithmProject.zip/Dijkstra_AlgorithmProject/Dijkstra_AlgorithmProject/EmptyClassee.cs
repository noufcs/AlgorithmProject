﻿using System;
namespace Dijkstra_AlgorithmProject
{
    public class EmptyClassee
    {
        public EmptyClassee()
        {
        }
    }
}
