﻿using System;
namespace Dijkstra_AlgorithmProject
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
